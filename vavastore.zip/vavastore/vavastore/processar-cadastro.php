<?php


require_once "conexao.php";

// Obter os dados do formulário
$nome = $_POST["nome"];
$email = $_POST["email"];
$senha = $_POST["senha"];

// Inserir os dados na tabela 'usuarios'
$sql = "INSERT INTO usuarios (nome, email, senha) VALUES ('$nome', '$email', '$senha')";

if ($mysqli->query($sql) === TRUE) {
    header("Location: cadastrar-sucesso.php");
    exit();
} else {
    echo "Erro ao cadastrar o usuário: " . $mysqli->error;
}

$mysqli->close();
?>
