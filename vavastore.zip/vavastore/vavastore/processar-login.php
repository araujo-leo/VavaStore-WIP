<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


var_dump($_POST);


require 'conexao.php';

// Obter os dados do formulário
$email = $_POST["email"];
$senha = $_POST["senha"];

//comparar dados da tabela usuário
$sql = "SELECT * FROM usuarios WHERE email='$email' AND senha='$senha';";

if ($results = $conn->query($sql)) {
    foreach($results as $result){
        $_SESSION['nome'] = $result['nome'];
        $_SESSION['email'] = $result['email'];
    }
    

    var_dump($_SESSION);
    header("Location: login/login.php?sucesso=1");
    exit();
} else {
    echo "Erro ao cadastrar o usuário: " . $conn->error;
}

$conn->close();
?>
