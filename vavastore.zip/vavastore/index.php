<?php
session_start();
require "processar-produtos.php";

$infoProdutos = processar_produtos();



?>

<!DOCTYPE html>
<html lang="pt-br">

<body style="background-color: rgb(238, 238, 238);">
    <?php
    include "navbar.php";

    if (isset($_GET['logout-sucesso']) && $_GET['logout-sucesso'] == 1) {
    ?>
        <script>
            Swal.fire({
                title: 'Sucesso',
                text: 'Logout feito com sucesso',
                icon: 'info',
                confirmButtonColor: '#3085d6',
                confirmButtonText: 'OK'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'index.php';
                }
            });
        </script>

    <?php }
    ?>


    <!-- Header-->
    <header class="bg-dark py-5">
        <div class="container px-4 px-lg-5 my-5">
            <div class="text-center text-white">
                <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">

                    <div class="carousel-inner">
                        <?php
                        $first = true; // Variável para controlar o primeiro item ativo
                        foreach ($infoProdutos as $produto) {
                        ?>
                            <div class="carousel-item <?php echo $first ? 'active' : ''; ?>">
                                <img class="d-block w-100" src="skins/<?php echo $produto['categoria']; ?>/<?php echo $produto['nome']; ?>.png" alt="<?php echo $produto['id'] ?> slide" style="max-height:190px">
                            </div>
                        <?php
                            $first = false; // Define o primeiro item como inativo após o primeiro loop
                        }
                        ?>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- Section-->



    <section class="py-5 " style="background-color: rgb(238, 238, 238);">
        <div class="container px-4 px-lg-5 mt-5">
            <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                <?php
                foreach ($infoProdutos as $produto) {

                    $nomeProduto = ucwords($produto['nome']); // Converte a primeira letra de cada palavra para maiúscula
                    $categoriaProduto = ucwords($produto['categoria']); // Converte a primeira letra de cada palavra para maiúscula
            ?>
                
                    <div class="col mb-5">
                        <div class="card h-100">
                            <!-- Product image -->
                            <img class="card-img-top py-2" style="max-height:120px;"src="skins/<?php echo $produto['categoria']; ?>/<?php echo $produto['nome']; ?>.png" alt="Product Image" />
                            <!-- Product details -->
                            <div class="card-body p-4">
                                <div class="text-center">
                                    <!-- Product name -->
                                    <h5 class="fw-bolder"><?php echo $nomeProduto; ?></h5>
                                    <!-- Product category -->
                                    <p class="text-muted"><?php echo $categoriaProduto; ?></p>
                                    <!-- Product price -->
                                    <h6 class="mb-3"><?php echo $produto['preco']; ?></h6>
                                </div>
                            </div>
                            <!-- Product actions -->
                            <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                <div class="text-center">
                                    <a href="?adicionar=<?php echo $produto["id"]?>" class="btn btn-outline-dark mt-auto"> Add to cart</a>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                <?php                                        

                }

                ?>
                <?php
                    
                    if(isset($_GET["adicionar"])){
                        $idProduto = (int) $_GET["adicionar"];
                        if ($idProduto >= 1 && $idProduto <= count($infoProdutos)) {
                            $produto = $infoProdutos[$idProduto - 1]; // Subtrai 1 para obter o índice correto

                            if(isset($_SESSION['carrinho'][$idProduto])){
                                $_SESSION['carrinho'][$idProduto]['quantidade']++;
                            }else{
                                $_SESSION['carrinho'][$idProduto] = array('quantidade' => 1, 'nome' => $produto['nome'], 'descricao' => $produto['descricao'], 'categoria' => $produto['categoria'], 'preco' => $produto['preco']);
                            }

                            // Exibir SweetAlert
                            echo '<script>
                                Swal.fire({
                                    title: "Produto adicionado ao carrinho com sucesso!",
                                    text: "",
                                    icon: "success",
                                    showCancelButton: true,
                                    confirmButtonColor: "#3085d6",
                                    cancelButtonColor: "#008000",
                                    confirmButtonText: "Ir para o Carrinho",
                                    cancelButtonText: "Continuar Comprando"
                                }).then((result) => {
                                    if (result.isConfirmed) {
                                        // Redirecione para a página do carrinho
                                        window.location.href = "carrinho.php"; // Substitua "carrinho.php" pela URL da página do carrinho
                                    } else {
                                        // Faça algo se o usuário optar por continuar comprando
                                        // Por exemplo: window.location.href = "outra_pagina.php";
                                    }
                                })
                            </script>';
                        } else {
                            die("Produto não encontrado.");
                        }
                    }
                    ?>
            </div>
        </div>
    </section>
    <?php include "footer.php"; ?>
    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>
</body>
</html>