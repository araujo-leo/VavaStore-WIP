-- Crie um banco de dados (se ainda não existir)
CREATE DATABASE IF NOT EXISTS VavaStore;

-- Use o banco de dados recém-criado
USE VavaStore;

create table usuarios (
nome varchar(40),
email varchar(255),
senha varchar(255));

select * from usuarios;