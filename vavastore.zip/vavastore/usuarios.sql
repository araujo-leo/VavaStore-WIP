-- Crie um banco de dados (se ainda não existir)
CREATE DATABASE IF NOT EXISTS VavaStore;

-- Use o banco de dados recém-criado
USE VavaStore;

create table usuarios (
nome varchar(40),
email varchar(255),
senha varchar(255));


select * from usuarios;

CREATE TABLE produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    descricao TEXT,
    categoria VARCHAR(100),
    preco DECIMAL(10, 2),
    disponibilidade VARCHAR(50)
);

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('ruina', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'ghost', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('soberania', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'ghost', 49.99, 'Em Estoque');

select * from produtos;
