-- Crie um banco de dados (se ainda não existir)
CREATE DATABASE IF NOT EXISTS VavaStore;

-- Use o banco de dados recém-criado
USE VavaStore;

create table usuarios (
nome varchar(40),
email varchar(255),
senha varchar(255));


select * from usuarios;

CREATE TABLE produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    descricao TEXT,
    categoria VARCHAR(100),
    preco DECIMAL(10, 2),
    disponibilidade VARCHAR(50)
);

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('ruina', 'Uma skin assustadora e misteriosa com um toque sombrio para o seu Ghost.', 'ghost', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('magipunk', 'Transforme seu Ghost em uma entidade mágica e punk com esta skin intrigante.', 'ghost', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('soberania', 'Exiba sua soberania no campo de batalha com esta skin imponente para o Ghost.', 'ghost', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('gaia', 'A faca Gaia traz a força da natureza para suas mãos, com um design imponente e elegante.', 'faca', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('reconhecimento', 'Um punhal de reconhecimento com um visual afiado, perfeito para jogadores táticos.', 'faca', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('VCT', 'Celebre a vitória com a faca VCT, uma adição triunfante ao seu arsenal.', 'faca', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('ancifogo', 'Equipamento-se com a skin Ancifogo e incendeie o campo de batalha como um verdadeiro operador.', 'operator', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('araxys', 'A skin Araxys oferece uma estética única para operadores, destacando-se com elegância e poder.', 'operator', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('lugubre', 'A skin Lugubre traz uma aura sombria aos operadores, perfeita para os que preferem as sombras.', 'operator', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('champions-2022', 'A skin Phanton Champions 2022 é uma celebração da vitória, projetada para os verdadeiros campeões.', 'phantom', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('protocolo', 'O Protocolo é uma skin Phanton que emana uma aura tecnológica futurista, perfeita para os entusiastas da alta tecnologia.', 'phantom', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('reconhecimento', 'A skin Phanton Reconhecimento oferece um estilo tático e distinto para os jogadores astutos.', 'phantom', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('ion', 'A Sheriff Ion é uma pistola de alta tecnologia que vai surpreender seus inimigos com sua elegância e eficácia.', 'sheriff', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('neo', 'A skin Sheriff Neo oferece um design moderno e futurista, garantindo que você se destaque no campo de batalha.', 'sheriff', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('singularidade', 'Experimente a singularidade com a skin Sheriff, uma adição única ao seu arsenal.', 'sheriff', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('netuno', 'A skin Vandal Netuno traz as profundezas do oceano para o seu rifle, com um design impressionante e assustador.', 'vandal', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('saqueadora', 'A skin Vandal Saqueadora é perfeita para os jogadores que buscam pilhar a vitória no campo de batalha.', 'vandal', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('netuno', 'Mergulhe nas profundezas do oceano com a skin Vandal Netuno, uma escolha formidável para os guerreiros aquáticos.', 'vandal', 49.99, 'Em Estoque');


select * from produtos;
