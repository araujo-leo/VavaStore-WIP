-- Crie um banco de dados (se ainda não existir)
CREATE DATABASE IF NOT EXISTS VavaStore;

-- Use o banco de dados recém-criado
USE VavaStore;

create table usuarios (
nome varchar(40),
email varchar(255),
senha varchar(255));


select * from usuarios;

CREATE TABLE produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    descricao TEXT,
    categoria VARCHAR(100),
    preco DECIMAL(10, 2),
    disponibilidade VARCHAR(50)
);

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('ruina', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'ghost', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('soberania', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'ghost', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('magipunk', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'ghost', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('saqueadora', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'vandal', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('netuno', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'vandal', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('gaia', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'faca', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('reconhecimento', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'faca', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('vct', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'faca', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('ancifogo', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'operator', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('araxys', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'operator', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('lugubre', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'operator', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('champions', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'phantom', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('protocolo', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'phantom', 49.99, 'Em INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('ruina', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'ghost', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('soberania', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'ghost', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('magipunk', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'ghost', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('saqueadora', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'vandal', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('netuno', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'vandal', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('gaia', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'faca', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('reconhecimento', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'faca', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('vct', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'faca', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('ancifogo', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'operator', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('araxys', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'operator', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('lugubre', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'operator', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('champions', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'phantom', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('protocolo', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'phantom', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('reconhecimento', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'phantom', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('ion', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'sheriff', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('neo', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'sheriff', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('singularidade', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'sheriff', 49.99, 'Em Estoque');

select * from produtos;produtosidEstoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('reconhecimento', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'phantom', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('ion', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'sheriff', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('neo', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'sheriff', 49.99, 'Em Estoque');

INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade)
VALUES ('singularidade', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'sheriff', 49.99, 'Em Estoque');

select * from produtos;
