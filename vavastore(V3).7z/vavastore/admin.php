<?php 
session_start();
include "navbar.php";
require "processar-produtos.php";

$infoProdutos = processar_produtos();
?>


<!DOCTYPE html>
<html lang="pt-br">

<!-- Resto do seu código HTML aqui -->

<body style="background-color: rgb(238, 238, 238);">
    <?php
    if (!empty($infoProdutos)) {
    ?>
        <div class="container text-center mt-lg-5">
            <table class="table table-striped table-bordered text-center">
                <thead class="thead-dark">
                    <tr>
                        <th>Nome do Produto</th>
                        <th>Categoria</th>
                        <th>Preço</th>
                        <th>Descrição</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach ($infoProdutos as $produto) {
                        // Preencha os detalhes do produto
                        $nomeProduto = $produto['nome'];
                        $categoriaProduto = $produto['categoria'];
                        $precoProduto = $produto['preco'];
                        $descricaoProduto = $produto['descricao'];

                        // Exibir os dados na tabela
                        echo '<tr>';
                        echo '<td>' . $nomeProduto . '</td>';
                        echo '<td>' . $categoriaProduto . '</td>';
                        echo '<td>R$ ' . $precoProduto . '</td>';
                        echo '<td>'.$descricaoProduto .'</td>';
                        echo '<td class="d-flex">
                                <form action="editar-produto.php" method="GET">
                                    <input type="hidden" name="id" value="' . $produto['id'] . '">
                                    <input type="submit" class="btn btn-primary" value="Editar">
                                </form>
                                <form action="deletar-produto.php" method="GET">
                                    <input type="hidden" name="id" value="' . $produto['id'] . '">
                                    <input type="submit" class="btn btn-danger" value="Deletar">
                                </form>
                            </td>';
                        echo '</tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    <?php
    } else {
        echo 'Não há produtos disponíveis.';
    }

    // Resto do seu código HTML e PHP aqui

    ?>
</body>

</html>
