<?php

require "conexao.php";

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["id"])){
    $produtoToRemove = $_GET["id"];

    $query = "DELETE FROM produtos WHERE id = $produtoToRemove";
    $resultado = $conn->query($query);

    if($resultado){
        header("Location: admin.php"); 
        exit;

    }else{
        echo("erro");
    }
}