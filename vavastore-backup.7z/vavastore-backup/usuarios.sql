	-- Crie um banco de dados (se ainda não existir)
	CREATE DATABASE IF NOT EXISTS VavaStore;

	-- Use o banco de dados recém-criado
	USE VavaStore;

	-- Crie a tabela "usuarios"
	CREATE TABLE usuarios (
		id INT AUTO_INCREMENT PRIMARY KEY,
		nome VARCHAR(40),
		email VARCHAR(255),
		senha VARCHAR(255),
		perfil INT DEFAULT 0
	);

	-- Insira usuários de exemplo
	INSERT INTO usuarios (nome, email, senha, perfil) VALUES
		('Adm', 'adm@adm.com', 'adm123', 1),
		('Usuário 1', 'usuario1@example.com', 'senha123', 0),
		('Usuário 2', 'usuario2@example.com', 'senha456', 0);

	-- Crie a tabela "produtos"
	CREATE TABLE produtos (
		id INT AUTO_INCREMENT PRIMARY KEY,
		nome VARCHAR(255) NOT NULL,
		descricao TEXT,
		categoria VARCHAR(100),
		preco DECIMAL(10, 2),
		disponibilidade VARCHAR(50)
	);

	-- Insira produtos de exemplo
	INSERT INTO produtos (nome, descricao, categoria, preco, disponibilidade) VALUES
		('Ruina', 'Uma skin Ghost misteriosa e assustadora com um visual sombrio.', 'ghost', 49.99, 'Em Estoque'),
		('Soberania', 'Outra descrição de produto de exemplo.', 'ghost', 39.99, 'Em Estoque'),
		('Magipunk', 'Mais uma descrição de produto de exemplo.', 'ghost', 29.99, 'Em Estoque'),
		('Saqueadora', 'Descrição de produto para a categoria Vandal.', 'vandal', 19.99, 'Em Estoque'),
		('Netuno', 'Descrição de produto para a categoria Vandal.', 'vandal', 59.99, 'Em Estoque'),
		('Gaia', 'Descrição de produto para a categoria Faca.', 'faca', 69.99, 'Em Estoque'),
		('Reconhecimento', 'Descrição de produto para a categoria Faca.', 'faca', 49.99, 'Em Estoque'),
		('VCT', 'Descrição de produto para a categoria Faca.', 'faca', 79.99, 'Em Estoque'),
		('Ancifogo', 'Descrição de produto para a categoria Operator.', 'operator', 99.99, 'Em Estoque'),
		('Araxys', 'Descrição de produto para a categoria Operator.', 'operator', 89.99, 'Em Estoque'),
		('Lugubre', 'Descrição de produto para a categoria Operator.', 'operator', 79.99, 'Em Estoque'),
		('Champions', 'Descrição de produto para a categoria Phantom.', 'phantom', 59.99, 'Em Estoque'),
		('Protocolo', 'Descrição de produto para a categoria Phantom.', 'phantom', 69.99, 'Em Estoque'),
		('Reconhecimento', 'Descrição de produto para a categoria Phantom.', 'phantom', 49.99, 'Em Estoque'),
		('Ion', 'Descrição de produto para a categoria Sheriff.', 'sheriff', 79.99, 'Em Estoque'),
		('Neo', 'Descrição de produto para a categoria Sheriff.', 'sheriff', 89.99, 'Em Estoque'),
		('Singularidade', 'Descrição de produto para a categoria Sheriff.', 'sheriff', 99.99, 'Em Estoque');

	-- Consulta para ver os usuários
	SELECT * FROM usuarios;

	-- Consulta para ver os produtos
	SELECT * FROM produtos;
    
SELECT * FROM usuarios;