<?php
require_once('vendor/autoload.php'); // Carregue a biblioteca do Stripe

// Configure a chave secreta do Stripe
\Stripe\Stripe::setApiKey('sk_test_51ORhQRG2Ki4fw9xAHuXZnxowlMPSCkWbkw0Uaa2Q47deCF5etW5dwNS7XUI9Dts0jHQv1s5PVuzdQe9GAvJM76h300eXR4NMmk');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['token'])) {
        $token = $_POST['token'];
        var_dump($_POST['token']);
        die();

        // Crie uma cobrança no Stripe usando o token do cartão
        try {
            $charge = \Stripe\Charge::create([
                'amount' => $_POST['preco'] * 100, // Valor em centavos
                'currency' => 'brl', // Moeda (neste caso, Real Brasileiro)
                'source' => $token, // Token do cartão
                'description' => 'Compra de produtos' // Descrição opcional
            ]);

            // Sucesso na cobrança - faça qualquer ação necessária aqui após o pagamento bem-sucedido

            echo "Pagamento processado com sucesso!";
        } catch (\Stripe\Exception\CardException $e) {
            // Erro com o cartão, exiba a mensagem de erro
            echo "Erro ao processar o pagamento: " . $e->getMessage();
        }
    } else {
        echo "Token do cartão não recebido.";
    }
}
?>
