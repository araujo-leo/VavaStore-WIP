<?php
session_start();
// Função para atualizar a quantidade de um item no carrinho
function updateQuantity($produtoId, $quantidade) {
    if (isset($_SESSION['carrinho'][$produtoId])) {
      
        $_SESSION['carrinho'][$produtoId]['quantidade'] = $quantidade;
    }
}

// Função para remover um item do carrinho
function removeItem($produtoId) {
    if (isset($_SESSION['carrinho'][$produtoId])) {
        unset($_SESSION['carrinho'][$produtoId]);
    }
}

if (isset($_POST['update'])) {
  $produtoId = $_POST['produto_id'];
  $acao = $_POST['update'];

  if ($acao === 'decrement') {
      if ($_SESSION['carrinho'][$produtoId]['quantidade'] > 1) {
          $_SESSION['carrinho'][$produtoId]['quantidade']--;
      } else {
          // Se a quantidade for 1, remova o item do carrinho.
          unset($_SESSION['carrinho'][$produtoId]);
      }
  } elseif ($acao === 'increment') {
      // Se o botão de "+" foi clicado, aumente a quantidade em 1.
      $_SESSION['carrinho'][$produtoId]['quantidade']++;
  }
}

$totalItens = 0;

if (isset($_SESSION['carrinho'])) {
    $total = 0; // Variável para armazenar o valor total

    foreach ($_SESSION['carrinho'] as $key => $value) {
        $totalItens++; // Incrementa a quantidade de itens no carrinho
        $_SESSION['totalItens'] = $totalItens;
    }
}else{
  $_SESSION['totalItens'] = $totalItens;
}
?>