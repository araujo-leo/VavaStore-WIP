<?php
require "conexao.php";
session_start();

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["id"])) {
    $produtoToRemove = $_GET["id"];

    $query = "DELETE FROM produtos WHERE id = $produtoToRemove";
    $resultado = $conn->query($query);

    if ($resultado) {
        // Recria a sessão do carrinho
        $carrinho = array();
        foreach ($infoProdutos as $produto) {
            $id = $produto['id'];
            if (isset($_SESSION['carrinho'][$id])) {
                $carrinho[$id] = $_SESSION['carrinho'][$id];
            }
        }

        // Atualiza a sessão do carrinho com o novo array
        $_SESSION['carrinho'] = $carrinho;

        header("Location: admin/admin.php");
        exit;
    } else {
        echo("erro");
    }
}
